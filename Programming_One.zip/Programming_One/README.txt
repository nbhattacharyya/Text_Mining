This project is meant to be run in Eclipse. 
REFERENCED LIBRARIES from Stanford core NLP:
ejml-core-0.38.jar
ejml-core-0.38-sources.jar
ejml-ddense-0.38.jar
ejml-ddense-0.38-sources.jar
ejml-simple-0.38.jar
ejml-simple-0.38-sources.jar
javax.activation-api-1.2.0.jar
javax.activation-api-1.2.0-sources.jar
javax.json.jar
javax.json-api-1.0-sources.jar
jaxb-api-2.4.0-b180830.0359.jar
jaxb-api-2.4.0-b180830.0359-sources.jar
jaxb-core-2.3.0.1.jar
jaxb-core-2.3.0.1-sources.jar
jaxb-impl-2.4.0-b180830.0438.jar
joda-time.jar
joda-time-2.10.5-sources.jar
jollyday.jar
jollyday-0.4.9-sources.jar
protobuf.jar
slf4j-api.jar
slf4j-simple.jar
stanford-corenlp-4.1.0.jar
stanford-corenlp-4.1.0-javadoc.jar
stanford-corenlp-4.1.0-models.jar
stanford-corenlp-4.1.0-sources.jar
stanford-corenlp-4.1.0\xom.jar
xom-1.3.2-sources.jar
Jama-1.0.3.jar
VectorGraphics2D-0.13.jar
gral-core-0.11.jar
To run: simply hit run and all results will be printed out to the console. 